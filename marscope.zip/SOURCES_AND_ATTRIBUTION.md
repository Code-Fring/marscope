# MARSCOPE – Sources and Attribution

## Images
- All visuals in the deck (hero background, slide 2 panel, slide 4 raster panels) were procedurally generated for illustration with Python (NumPy/Pillow). They are NOT NASA imagery and NOT MOLA data. Each is captioned as illustrative or synthetic on the slide.
- No NASA logos, insignia or mission patches are used.
- Slide 3 tiles are placeholders. Replace each with a real screenshot from the running MARSCOPE app.

## Scientific references (facts used on slide 4)
- MOLA (Mars Orbiter Laser Altimeter), Mars Global Surveyor: NASA / GSFC / MOLA Science Team. Data archive: PDS Geosciences Node, Washington University in St. Louis, https://pds-geosciences.wustl.edu/missions/mgs/
- MOLA global topography overview: https://www.planetary.org/space-images/mars-orbiter-laser-altimeter-map-of-mars (credit: NASA / GSFC / MOLA Science Team)
- Please double-check the "roughly 29 km of relief (Hellas Planitia to Olympus Mons)" figure against the MOLA documentation before presenting.

## Project sources
- Repository: https://github.com/Code-Fring/marscope (architecture and status as summarized by the team; the repo could not be opened directly from this environment).

## Resources to cite only if actually integrated
HiRISE (https://www.uahirise.org/), NASA Mars Trek (https://trek.nasa.gov/mars/), NASA Planetary Data System (https://pds.nasa.gov/). They are not claimed as integrated in the deck.
