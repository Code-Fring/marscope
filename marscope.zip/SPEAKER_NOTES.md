# MARSCOPE – Speaker Notes (about 2–3 minutes)

**1. MARSCOPE.** We are presenting MARSCOPE for the Interplanetary Survival Guide: Martian Map challenge. It is an interactive platform that brings Martian geography, climate, geology, water and survival information into one map. The background is illustrative terrain we generated, not NASA imagery.

**2. The challenge.** Mars has extreme relief and unfamiliar terrain. Planning exploration means understanding elevation, recognising geology, finding points of interest and navigating, yet the data is spread across separate archives. An integrated map lowers that barrier.

**3. Our solution.** MARSCOPE is a React and TypeScript app with a MapLibre GL map, Deck.gl layers and a FastAPI backend, organised into seven views: Climate, Geology, Library, Mission, Radiation, Survival and Water. The tiles show screenshots from the running app.

**4. The science.** MOLA measured Mars from orbit: laser pulse travel time gives distance, and with the spacecraft position, elevation. A DEM stores those heights on a grid. We hold a roughly 2 GB MOLA DEM, with its download documented in the repository. The left panels are synthetic illustrations, and in-app processing of the raster is planned, not claimed.

**5. Technology.** NASA data feeds a FastAPI backend with routers per dataset. The React 18 frontend, built with Vite, uses Zustand stores and MapLibre GL with Deck.gl across seven views. GitHub Actions runs CI.

**6. Impact and future.** Working today: the map, seven views, backend, state and CI. Planned: 3D terrain, slope analysis, route planning, landing-site recommendation and MOLA TIFF processing. MARSCOPE gives no validated safety or landing guidance.

**7. Closing.** One layer at a time, MARSCOPE makes Martian data explorable. Understanding the terrain is the first step toward exploring the unknown. Our code is on GitHub. Thank you.
